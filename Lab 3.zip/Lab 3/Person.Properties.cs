﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_Assingment_3
{
   
        internal partial class Person
        {
            public string FirstName { get; set; }
            public string LastName { get; set; }
        }
    }
