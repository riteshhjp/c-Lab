﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_Assingment_3
{
        internal partial class Employee1
        {
            public string Name { get; set; }
            public int Age { get; set; }
            public decimal BaseSalary { get; set; }
            public decimal Bonus { get; set; }
            public decimal Deductions { get; set; }
        }
    }
