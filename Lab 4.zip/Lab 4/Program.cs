﻿using System;

namespace LabAssignment
{
    // Q1: BankAccount
    class BankAccount
    {
        public decimal Balance { get; private set; }

        public void Deposit(decimal amount)
        {
            Balance += amount;
        }

        public void Withdraw(decimal amount)
        {
            if (amount <= Balance)
                Balance -= amount;
            else
                Console.WriteLine("Insufficient balance!");
        }
    }

    // Q2: Student
    class Student
    {
        private int age;
        public int Age
        {
            get { return age; }
            set
            {
                if (value >= 5 && value <= 25)
                    age = value;
                else
                    age = 18; // default
            }
        }
    }

    // Q3: Employee
    class Employee
    {
        private double basicSalary;
        public double BasicSalary
        {
            set { basicSalary = value; }
        }

        public double TotalSalary
        {
            get { return basicSalary + (basicSalary * 0.20); }
        }
    }

    // Q4: Product
    class Product
    {
        public double Price { get; set; }
        public double Discount { get; set; }

        public double FinalPrice()
        {
            return Price - (Price * Discount / 100);
        }
    }

    // Q5: Car
    class Car
    {
        private int speed;
        public int Speed
        {
            get { return speed; }
            set
            {
                if (value > 180)
                    speed = 180;
                else
                    speed = value;
            }
        }
    }

    // Q6: Delegate Operation
    delegate int Operation(int a, int b);

    class Arithmetic
    {
        public static int Add(int a, int b) => a + b;
        public static int Subtract(int a, int b) => a - b;
    }

    // Q7: Delegate FormatText
    delegate string FormatText(string input);

    class TextFormatter
    {
        public static string ToUpperCase(string input) => input.ToUpper();
        public static string ToLowerCase(string input) => input.ToLower();
    }

    // Q8: Delegate BillingOperation
    delegate double BillingOperation(double amount);

    class Billing
    {
        public static double ShowTotal(double amount)
        {
            Console.WriteLine($"Original Price: {amount}");
            return amount;
        }

        public static double ApplyDiscount(double amount)
        {
            double discounted = amount - (amount * 0.10);
            Console.WriteLine($"After Discount: {discounted}");
            return discounted;
        }

        public static double AddTax(double amount)
        {
            double taxed = amount + (amount * 0.18);
            Console.WriteLine($"After GST: {taxed}");
            return taxed;
        }

        public static double FinalBill(double amount)
        {
            Console.WriteLine($"Final Payable Amount: {amount}");
            return amount;
        }
    }

    // Q9: Delegate ConvertTemperature
    delegate double ConvertTemperature(double celsius);

    class TemperatureConverter
    {
        public static double ToFahrenheit(double celsius) => (celsius * 9 / 5) + 32;
        public static double ToKelvin(double celsius) => celsius + 273.15;
    }

    // Q10: Delegate Notifier
    delegate void Notifier(string message);

    class Notification
    {
        public static void SendEmail(string message) => Console.WriteLine($"Email: {message}");
        public static void SendSMS(string message) => Console.WriteLine($"SMS: {message}");
    }

    // Main Program
    class Program
    {
        static void Main(string[] args)
        {
            // Q1
            BankAccount account = new BankAccount();
            account.Deposit(1000);
            account.Withdraw(500);
            Console.WriteLine($"Balance: {account.Balance}\n");

            // Q2
            Student s1 = new Student { Age = 4 };
            Student s2 = new Student { Age = 20 };
            Student s3 = new Student { Age = 30 };
            Console.WriteLine($"Age set to 4 → {s1.Age}");
            Console.WriteLine($"Age set to 20 → {s2.Age}");
            Console.WriteLine($"Age set to 30 → {s3.Age}\n");

            // Q3
            Employee emp = new Employee();
            emp.BasicSalary = 30000;
            Console.WriteLine($"Total Salary: {emp.TotalSalary}\n");

            // Q4
            Product p = new Product { Price = 2000, Discount = 10 };
            Console.WriteLine($"Final Price: {p.FinalPrice()}\n");

            // Q5
            Car car = new Car();
            car.Speed = 150;
            Console.WriteLine($"Speed set to 150 → {car.Speed}");
            car.Speed = 200;
            Console.WriteLine($"Speed set to 200 → {car.Speed}\n");

            // Q6
            Operation opAdd = Arithmetic.Add;
            Operation opSub = Arithmetic.Subtract;
            Console.WriteLine($"Add(10,5): {opAdd(10, 5)}");
            Console.WriteLine($"Subtract(10,5): {opSub(10, 5)}\n");

            // Q7
            FormatText ftUpper = TextFormatter.ToUpperCase;
            FormatText ftLower = TextFormatter.ToLowerCase;
            Console.WriteLine(ftUpper("Hello World"));
            Console.WriteLine(ftLower("Hello World") + "\n");

            // Q8
            BillingOperation billOps = Billing.ShowTotal;
            billOps += Billing.ApplyDiscount;
            billOps += Billing.AddTax;
            billOps += Billing.FinalBill;
            billOps(5000);
            Console.WriteLine();

            // Q9
            ConvertTemperature convF = TemperatureConverter.ToFahrenheit;
            ConvertTemperature convK = TemperatureConverter.ToKelvin;
            Console.WriteLine($"25°C in Fahrenheit: {convF(25)}");
            Console.WriteLine($"25°C in Kelvin: {convK(25)}\n");

            // Q10
            Notifier notify = Notification.SendEmail;
            notify += Notification.SendSMS;
            notify("Assignment Submitted Successfully");
        }
    }
}
