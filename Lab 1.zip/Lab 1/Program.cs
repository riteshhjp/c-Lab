﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Q 1
            int[] transactions = { 200, -150, 340, 500, -100 };
            int sum = 0;

            foreach (int t in transactions)
            {
                sum += t;
            }

            Console.WriteLine("Total Sum: " + sum);

            // Q 2

            float[] scores = { 85.5f, 90.3f, 78.4f, 88.9f, 92.1f };
            float total = 0;

            foreach (float score in scores)
            {
                total += score;
            }

            float average = total / scores.Length;
            Console.WriteLine("Average Score: " + average);

            // Q 3 

            int[] prices = { 1500, 2300, 999, 3200, 1750 };
            int max = prices[0];

            foreach (int price in prices)
            {
                if (price > max)
                {
                    max = price;
                }
            }

            Console.WriteLine("Most Expensive Item: " + max);

            // Q 4
            int[] participantCodes = { 102, 215, 324, 453, 536 };
            int male = 0, female = 0;

            foreach (int code in participantCodes)
            {
                if (code % 2 == 0)
                    male++;
                else
                    female++;
            }

            Console.WriteLine("Males: " + male + ", Females: " + female);

            // Q 5

            int[] searchHistory = { 101, 202, 303, 404, 505 };

            for (int i = searchHistory.Length - 1; i >= 0; i--)
            {
                Console.WriteLine(searchHistory[i] + " ");
            }

            // Q 6

            int[] measurements = { 2, 4, 6, 8 };
            int factor = 3;

            for (int i = 0; i < measurements.Length; i++)
            {
                measurements[i] *= factor;
            }

            Console.WriteLine("Adjusted Measurements: " + string.Join(", ", measurements));

            // Q 7
            int[] bookCodes = { 101, 203, 304, 405, 506 };
            int searchCode = 304;
            int index = -1;

            for (int i = 0; i < bookCodes.Length; i++)
            {
                if (bookCodes[i] == searchCode)
                {
                    index = i;
                    break;
                }
            }

            Console.WriteLine(index != -1 ? "Found at index: " + index : "Not Found");

            // Q 8
            int[] grades = { 56, 78, 89, 45, 67 };
            Array.Sort(grades);
            Console.WriteLine("Second Smallest Grade: " + grades[1]);

            // Q 9
            int[] ids = { 102, 215, 102, 324, 215 };
            List<int> unique = new List<int>();

            foreach (int id in ids)
            {
                if (!unique.Contains(id))
                {
                    unique.Add(id);
                }
            }

            Console.WriteLine("Unique IDs: " + string.Join(", ", unique));
            // Q 10
            int[] dataset1 = { 1, 2, 3, 4, 5 };
            int[] dataset2 = { 3, 4, 5, 6, 7 };
            List<int> common = new List<int>();

            foreach (int d1 in dataset1)
            {
                foreach (int d2 in dataset2)
                {
                    if (d1 == d2 && !common.Contains(d1))
                    {
                        common.Add(d1);
                    }
                }
            }

            Console.WriteLine("Common Elements: " + string.Join(", ", common));

            






        }
    }
}
