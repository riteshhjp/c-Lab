﻿using System;
using System.Collections.Generic;

namespace LabAssignment2
{
    // Experiment 1: UserProfile with validation
    class UserProfile
    {
        private string username;
        private string password;
        private string email;

        public void SetUsername(string uname) => username = uname;

        public void SetPassword(string pwd)
        {
            if (pwd.Length >= 6)
                password = pwd;
            else
                Console.WriteLine("Password must be at least 6 characters.");
        }

        public void SetEmail(string mail)
        {
            if (mail.Contains("@"))
                email = mail;
            else
                Console.WriteLine("Invalid email format.");
        }

        public void Display()
        {
            Console.WriteLine($"Username: {username}, Email: {email}");
        }
    }

    // Experiment 2: Vehicle inheritance
    class Vehicle
    {
        public string Make { get; set; }
        public string Model { get; set; }
        public int Year { get; set; }

        public Vehicle(string make, string model, int year)
        {
            Make = make;
            Model = model;
            Year = year;
        }

        public virtual void DisplayDetails()
        {
            Console.WriteLine($"Make: {Make}, Model: {Model}, Year: {Year}");
        }
    }

    class Truck : Vehicle
    {
        public int LoadCapacity { get; set; }

        public Truck(string make, string model, int year, int capacity)
            : base(make, model, year) => LoadCapacity = capacity;

        public override void DisplayDetails()
        {
            base.DisplayDetails();
            Console.WriteLine($"Load Capacity: {LoadCapacity} tons");
        }
    }

    class Bus : Vehicle
    {
        public int SeatingCapacity { get; set; }

        public Bus(string make, string model, int year, int seats)
            : base(make, model, year) => SeatingCapacity = seats;

        public override void DisplayDetails()
        {
            base.DisplayDetails();
            Console.WriteLine($"Seating Capacity: {SeatingCapacity} passengers");
        }
    }

    // Experiment 3: Calculator with method overloading
    class Calculator
    {
        public int Add(int a, int b) => a + b;
        public int Add(int a, int b, int c) => a + b + c;
        public float Add(float a, float b) => a + b;
        public double Add(double a, double b) => a + b;
        public double Add(int a, double b) => a + b;
    }

    // Experiment 4: Abstract Employee
    abstract class Employee
    {
        public string Name { get; set; }
        public int Id { get; set; }

        public Employee(string name, int id)
        {
            Name = name;
            Id = id;
        }

        public abstract double CalculateSalary();
    }

    class FullTimeEmployee : Employee
    {
        public double MonthlySalary { get; set; }

        public FullTimeEmployee(string name, int id, double salary)
            : base(name, id) => MonthlySalary = salary;

        public override double CalculateSalary() => MonthlySalary;
    }

    class PartTimeEmployee : Employee
    {
        public int HoursWorked { get; set; }
        public double HourlyRate { get; set; }

        public PartTimeEmployee(string name, int id, int hours, double rate)
            : base(name, id)
        {
            HoursWorked = hours;
            HourlyRate = rate;
        }

        public override double CalculateSalary() => HoursWorked * HourlyRate;
    }

    // Experiment 5: Student with overloaded constructors
    class Student
    {
        public string Name { get; set; }
        public int RollNo { get; set; }
        public double Marks { get; set; }

        public Student() { }

        public Student(string name, int roll)
        {
            Name = name;
            RollNo = roll;
        }

        public Student(string name, int roll, double marks)
        {
            Name = name;
            RollNo = roll;
            Marks = marks;
        }

        public void Display()
        {
            Console.WriteLine($"Name: {Name}, Roll No: {RollNo}, Marks: {Marks}");
        }
    }

    // Experiment 6: Product with validation
    class Product
    {
        public int ProductID { get; set; }
        public string ProductName { get; set; }

        private double price;
        public double Price
        {
            get => price;
            set
            {
                if (value >= 0)
                    price = value;
                else
                    Console.WriteLine("Price cannot be negative.");
            }
        }

        public int Quantity { get; set; }

        public void PrintDetails()
        {
            Console.WriteLine($"ID: {ProductID}, Name: {ProductName}, Price: {Price}, Quantity: {Quantity}");
        }
    }

    // Experiment 7: Library Management System
    class Book
    {
        public string Title { get; set; }
        public bool IsAvailable { get; set; } = true;
    }

    class Member
    {
        public string Name { get; set; }
        public List<Book> BorrowedBooks { get; set; } = new List<Book>();
    }

    class Library
    {
        public List<Book> Books = new List<Book>();
        public List<Member> Members = new List<Member>();

        public void RegisterMember(string name)
        {
            Members.Add(new Member { Name = name });
            Console.WriteLine($"Member '{name}' registered.");
        }

        public void AddBook(string title)
        {
            Books.Add(new Book { Title = title });
            Console.WriteLine($"Book '{title}' added.");
        }

        public void LendBook(string title, string memberName)
        {
            Book book = Books.Find(b => b.Title == title && b.IsAvailable);
            Member member = Members.Find(m => m.Name == memberName);

            if (book != null && member != null)
            {
                book.IsAvailable = false;
                member.BorrowedBooks.Add(book);
                Console.WriteLine($"Book '{title}' lent to '{memberName}'.");
            }
            else
            {
                Console.WriteLine("Book not available or member not found.");
            }
        }

        public void ShowAvailableBooks()
        {
            Console.WriteLine("Available Books:");
            foreach (var book in Books)
                if (book.IsAvailable)
                    Console.WriteLine(book.Title);
        }
    }

    // Main Program
    class Program
    {
        static void Main(string[] args)
        {
            // Experiment 1
            Console.WriteLine("Experiment 1:");
            UserProfile user1 = new UserProfile();
            user1.SetUsername("Ritesh");
            user1.SetPassword("pass123");
            user1.SetEmail("ritesh@example.com");
            user1.Display();

            UserProfile user2 = new UserProfile();
            user2.SetUsername("Aman");
            user2.SetPassword("123"); // Invalid
            user2.SetEmail("amanexample.com"); // Invalid
            user2.Display();

            // Experiment 2
            Console.WriteLine("\nExperiment 2:");
            Truck truck = new Truck("Tata", "Ultra", 2022, 10);
            Bus bus = new Bus("Volvo", "9400", 2023, 50);
            truck.DisplayDetails();
            bus.DisplayDetails();

            // Experiment 3
            Console.WriteLine("\nExperiment 3:");
            Calculator calc = new Calculator();
            Console.WriteLine(calc.Add(5, 10));
            Console.WriteLine(calc.Add(1, 2, 3));
            Console.WriteLine(calc.Add(2.5f, 3.5f));
            Console.WriteLine(calc.Add(4.2, 5.8));
            Console.WriteLine(calc.Add(7, 2.3));

            // Experiment 4
            Console.WriteLine("\nExperiment 4:");
            FullTimeEmployee fte = new FullTimeEmployee("Ravi", 101, 50000);
            PartTimeEmployee pte = new PartTimeEmployee("Sneha", 102, 120, 250);
            Console.WriteLine($"Full-Time Salary: ₹{fte.CalculateSalary()}");
            Console.WriteLine($"Part-Time Salary: ₹{pte.CalculateSalary()}");

            // Experiment 5
            Console.WriteLine("\nExperiment 5:");
            Student s1 = new Student();
            Student s2 = new Student("Ritesh", 1);
            Student s3 = new Student("Aman", 2, 88.5);
            s1.Display();
            s2.Display();
            s3.Display();

            // Experiment 6
            Console.WriteLine("\nExperiment 6:");
            Product p1 = new Product { ProductID = 101, ProductName = "Laptop", Price = 55000, Quantity = 5 };
            Product p2 = new Product { ProductID = 102, ProductName = "Mouse", Price = -200, Quantity = 10 }; // Invalid
            p1.PrintDetails();
            p2.PrintDetails();

            // Experiment 7
            Console.WriteLine("\nExperiment 7:");
            Library lib = new Library();
            lib.AddBook("C# Basics");
            lib.AddBook("OOP Concepts");
            lib.RegisterMember("Ritesh");
            lib.LendBook("C# Basics", "R